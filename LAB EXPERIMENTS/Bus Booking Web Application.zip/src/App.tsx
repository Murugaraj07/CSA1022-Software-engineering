import { useEffect, useMemo, useState } from "react"
import {
  ArrowLeft,
  ArrowRight,
  ArrowUpDown,
  BusFront,
  CalendarDays,
  Check,
  ChevronDown,
  ChevronRight,
  CircleHelp,
  Clock3,
  CreditCard,
  Download,
  Filter,
  Info,
  LockKeyhole,
  MapPin,
  Menu,
  Minus,
  Navigation,
  Plus,
  Search,
  ShieldCheck,
  Smartphone,
  Star,
  Ticket,
  UserRound,
  UsersRound,
  WalletCards,
  Wifi,
  X,
  Zap,
} from "lucide-react"

type Page = "home" | "results" | "seats" | "passengers" | "review" | "payment" | "success" | "bookings"
type BusType = "Seater" | "Sleeper" | "Ultra Deluxe"
type SeatState = "available" | "booked" | "female" | "locked"

type BusTrip = {
  id: string
  operator: string
  type: BusType
  coach: string
  departure: string
  arrival: string
  duration: string
  rating: number
  reviews: number
  fare: number
  available: number
  amenities: string[]
  boarding: string[]
  dropping: string[]
}

type Passenger = { name: string age: string gender: string seat: string }
type Booking = {
  id: string
  pnr: string
  operator: string
  type: string
  from: string
  to: string
  date: string
  departure: string
  arrival: string
  seats: string[]
  passengers: Passenger[]
  amount: number
  status: string
}

const trips: BusTrip[] = [
  {
    id: "GL102",
    operator: "GreenLine Travels",
    type: "Sleeper",
    coach: "Volvo 9600 Multi-Axle AC Sleeper",
    departure: "21:30",
    arrival: "06:30",
    duration: "9h 00m",
    rating: 4.7,
    reviews: 1284,
    fare: 899,
    available: 18,
    amenities: ["AC", "WiFi", "Charging", "Blanket"],
    boarding: [
      "Chennai Central — 20:45",
      "Koyambedu — 21:10",
      "Madhuravoyal — 21:30",
    ],
    dropping: [
      "Electronic City — 05:45",
      "Silk Board — 06:10",
      "Majestic — 06:30",
    ],
  },
  {
    id: "SS209",
    operator: "SouthStar Travels",
    type: "Ultra Deluxe",
    coach: "Scania AC Ultra Deluxe",
    departure: "22:15",
    arrival: "06:45",
    duration: "8h 30m",
    rating: 4.5,
    reviews: 892,
    fare: 1049,
    available: 12,
    amenities: ["AC", "Charging", "Water", "Live tracking"],
    boarding: [
      "Koyambedu — 21:40",
      "Porur Toll — 22:05",
      "Madhuravoyal — 22:15",
    ],
    dropping: [
      "Electronic City — 06:00",
      "Silk Board — 06:20",
      "Majestic — 06:45",
    ],
  },
  {
    id: "ML441",
    operator: "MetroLink Travels",
    type: "Seater",
    coach: "BharatBenz 2+2 AC Seater",
    departure: "07:00",
    arrival: "14:45",
    duration: "7h 45m",
    rating: 4.3,
    reviews: 617,
    fare: 649,
    available: 27,
    amenities: ["AC", "Charging", "Water"],
    boarding: [
      "Chennai Central — 06:20",
      "Koyambedu — 06:40",
      "Poonamallee — 07:00",
    ],
    dropping: [
      "Electronic City — 14:00",
      "Silk Board — 14:20",
      "Majestic — 14:45",
    ],
  },
  {
    id: "RR330",
    operator: "Royal Roadways",
    type: "Sleeper",
    coach: "Mercedes-Benz AC Sleeper",
    departure: "23:00",
    arrival: "07:15",
    duration: "8h 15m",
    rating: 4.8,
    reviews: 2041,
    fare: 1199,
    available: 7,
    amenities: ["AC", "WiFi", "Charging", "Blanket"],
    boarding: [
      "Chennai Central — 22:10",
      "Koyambedu — 22:35",
      "Madhuravoyal — 23:00",
    ],
    dropping: [
      "Electronic City — 06:30",
      "Silk Board — 06:50",
      "Majestic — 07:15",
    ],
  },
]

const formatMoney = (value: number) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(value)

const formatDate = (date: string) =>
  new Date(`${date}T00:00:00`).toLocaleDateString("en-IN", {
    weekday: "short",
    day: "numeric",
    month: "short",
    year: "numeric",
  })

function Button({
  children,
  className = "",
  variant = "primary",
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "ghost" | "dark"
}) {
  return (
    <button className={`btn btn-${variant} ${className}`} {...props}>
      {children}
    </button>
  )
}

function App() {
  const [page, setPage] = useState<Page>("home")
  const [mobileNav, setMobileNav] = useState(false)
  const [authOpen, setAuthOpen] = useState(false)
  const [authMode, setAuthMode] = useState<"login" | "signup">("login")
  const [user, setUser] = useState<string | null>(() =>
    localStorage.getItem("wayfare_user"),
  )
  const [from, setFrom] = useState("Chennai")
  const [to, setTo] = useState("Bangalore")
  const [date, setDate] = useState("2026-10-25")
  const [passengerCount, setPassengerCount] = useState(2)
  const [activeTrip, setActiveTrip] = useState<BusTrip>(trips[0])
  const [selectedSeats, setSelectedSeats] = useState<string[]>([])
  const [deck, setDeck] = useState<"upper" | "lower">("lower")
  const [passengers, setPassengers] = useState<Passenger[]>([])
  const [boarding, setBoarding] = useState("")
  const [dropping, setDropping] = useState("")
  const [coupon, setCoupon] = useState("")
  const [couponApplied, setCouponApplied] = useState(false)
  const [terms, setTerms] = useState(false)
  const [paymentMethod, setPaymentMethod] = useState("upi")
  const [paying, setPaying] = useState(false)
  const [holdSeconds, setHoldSeconds] = useState(600)
  const [filtersOpen, setFiltersOpen] = useState(false)
  const [sort, setSort] = useState("Recommended")
  const [booking, setBooking] = useState<Booking | null>(null)
  const [savedBookings, setSavedBookings] = useState<Booking[]>(() => {
    try {
      return JSON.parse(localStorage.getItem("wayfare_bookings") || "[]")
    } catch {
      return []
    }
  })

  useEffect(() => {
    if (page !== "seats" || selectedSeats.length === 0) return
    const timer = window.setInterval(
      () => setHoldSeconds((value) => Math.max(0, value - 1)),
      1000,
    )
    return () => window.clearInterval(timer)
  }, [page, selectedSeats.length])

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }, [page])

  const price = useMemo(() => {
    const base = selectedSeats.length * activeTrip.fare
    const seatPremium =
      selectedSeats.filter((seat) => seat.startsWith("U")).length * 50
    const taxes = Math.round((base + seatPremium) * 0.05)
    const fee = selectedSeats.length ? 30 : 0
    const discount = couponApplied ? Math.min(100, base) : 0
    return {
      base,
      seatPremium,
      taxes,
      fee,
      discount,
      total: base + seatPremium + taxes + fee - discount,
    }
  }, [selectedSeats, activeTrip, couponApplied])

  const navigate = (next: Page) => {
    setPage(next)
    setMobileNav(false)
  }

  const searchBuses = () => {
    if (!date) return
    navigate("results")
  }

  const chooseTrip = (trip: BusTrip) => {
    setActiveTrip(trip)
    setSelectedSeats([])
    setHoldSeconds(600)
    setDeck(trip.type === "Ultra Deluxe" ? "upper" : "lower")
    navigate("seats")
  }

  const toggleSeat = (seat: string, state: SeatState) => {
    if (state === "booked" || state === "locked" || holdSeconds === 0) return
    if (selectedSeats.includes(seat)) {
      setSelectedSeats((current) => current.filter((item) => item !== seat))
      return
    }
    if (selectedSeats.length >= passengerCount) return
    setSelectedSeats((current) => [...current, seat])
    setHoldSeconds(600)
  }

  const continueToPassengers = () => {
    if (selectedSeats.length !== passengerCount || holdSeconds === 0) return
    if (!user) {
      setAuthMode("login")
      setAuthOpen(true)
      return
    }
    setPassengers(
      selectedSeats.map(
        (seat, index) =>
          passengers[index] || { name: "", age: "", gender: "", seat },
      ),
    )
    setBoarding(activeTrip.boarding[0])
    setDropping(activeTrip.dropping[activeTrip.dropping.length - 1])
    navigate("passengers")
  }

  const updatePassenger = (
    index: number,
    key: keyof Passenger,
    value: string,
  ) => {
    setPassengers((current) =>
      current.map((passenger, itemIndex) =>
        itemIndex === index ? { ...passenger, [key]: value } : passenger,
      ),
    )
  }

  const passengersValid = passengers.every(
    (passenger) =>
      passenger.name.trim().length > 2 &&
      Number(passenger.age) > 0 &&
      passenger.gender,
  )

  const completePayment = () => {
    setPaying(true)
    window.setTimeout(() => {
      const confirmed: Booking = {
        id: `BUS-2026-${Math.floor(100000 + Math.random() * 900000)}`,
        pnr: `${activeTrip.operator.slice(0, 3).toUpperCase()}${Math.floor(10000 + Math.random() * 90000)}`,
        operator: activeTrip.operator,
        type: activeTrip.coach,
        from,
        to,
        date,
        departure: activeTrip.departure,
        arrival: activeTrip.arrival,
        seats: selectedSeats,
        passengers,
        amount: price.total,
        status: "Confirmed",
      }
      const nextBookings = [confirmed, ...savedBookings]
      setBooking(confirmed)
      setSavedBookings(nextBookings)
      localStorage.setItem("wayfare_bookings", JSON.stringify(nextBookings))
      setPaying(false)
      navigate("success")
    }, 1500)
  }

  const signIn = (name = "Arjun Mehta") => {
    setUser(name)
    localStorage.setItem("wayfare_user", name)
    setAuthOpen(false)
  }

  return (
    <div className="app-shell">
      <Header
        page={page}
        user={user}
        mobileNav={mobileNav}
        setMobileNav={setMobileNav}
        navigate={navigate}
        openAuth={(mode) => {
          setAuthMode(mode)
          setAuthOpen(true)
        }}
      />

      {page === "home" && (
        <Home
          from={from}
          to={to}
          date={date}
          passengerCount={passengerCount}
          setFrom={setFrom}
          setTo={setTo}
          setDate={setDate}
          setPassengerCount={setPassengerCount}
          search={searchBuses}
        />
      )}

      {page === "results" && (
        <Results
          from={from}
          to={to}
          date={date}
          passengerCount={passengerCount}
          sort={sort}
          setSort={setSort}
          filtersOpen={filtersOpen}
          setFiltersOpen={setFiltersOpen}
          chooseTrip={chooseTrip}
          back={() => navigate("home")}
        />
      )}

      {page === "seats" && (
        <FlowPage step={2} back={() => navigate("results")}>
          <div className="seat-page-grid">
            <section className="panel seat-panel">
              <div className="seat-heading">
                <div>
                  <span className="eyebrow">Choose your place</span>
                  <h2>Select seats</h2>
                  <p>
                    {activeTrip.operator} · {activeTrip.coach}
                  </p>
                </div>
                <div className="hold-badge">
                  <Clock3 size={16} />
                  Held for{" "}
                  {String(Math.floor(holdSeconds / 60)).padStart(2, "0")}:
                  {String(holdSeconds % 60).padStart(2, "0")}
                </div>
              </div>
              <SeatLegend />
              {(activeTrip.type === "Sleeper" ||
                activeTrip.type === "Ultra Deluxe") && (
                <div className="deck-tabs">
                  <button
                    className={deck === "lower" ? "active" : ""}
                    onClick={() => setDeck("lower")}
                  >
                    Lower deck{" "}
                    {activeTrip.type === "Ultra Deluxe" && (
                      <small>Seater</small>
                    )}
                  </button>
                  <button
                    className={deck === "upper" ? "active" : ""}
                    onClick={() => setDeck("upper")}
                  >
                    Upper deck <small>Sleeper</small>
                  </button>
                </div>
              )}
              <SeatMap
                type={activeTrip.type}
                deck={deck}
                selected={selectedSeats}
                toggle={toggleSeat}
              />
            </section>
            <BookingSummary
              trip={activeTrip}
              from={from}
              to={to}
              selected={selectedSeats}
              passengerCount={passengerCount}
              price={price}
              action="Continue to passenger details"
              onAction={continueToPassengers}
              disabled={
                selectedSeats.length !== passengerCount || holdSeconds === 0
              }
            />
          </div>
        </FlowPage>
      )}

      {page === "passengers" && (
        <FlowPage step={3} back={() => navigate("seats")}>
          <div className="content-grid">
            <div>
              <section className="panel form-panel">
                <div className="section-title">
                  <span className="eyebrow">Traveller information</span>
                  <h2>Who’s travelling?</h2>
                  <p>Enter names exactly as shown on a valid ID.</p>
                </div>
                {passengers.map((passenger, index) => (
                  <div className="passenger-card" key={passenger.seat}>
                    <div className="passenger-card-title">
                      <div className="avatar">{index + 1}</div>
                      <div>
                        <strong>Passenger {index + 1}</strong>
                        <span>Seat {passenger.seat}</span>
                      </div>
                    </div>
                    <div className="form-grid">
                      <label className="field wide">
                        <span>Full name</span>
                        <input
                          value={passenger.name}
                          onChange={(event) =>
                            updatePassenger(index, "name", event.target.value)
                          }
                          placeholder="Enter passenger name"
                        />
                      </label>
                      <label className="field">
                        <span>Age</span>
                        <input
                          type="number"
                          value={passenger.age}
                          onChange={(event) =>
                            updatePassenger(index, "age", event.target.value)
                          }
                          placeholder="Age"
                        />
                      </label>
                      <label className="field">
                        <span>Gender</span>
                        <select
                          value={passenger.gender}
                          onChange={(event) =>
                            updatePassenger(index, "gender", event.target.value)
                          }
                        >
                          <option value="">Select</option>
                          <option>Male</option>
                          <option>Female</option>
                          <option>Other</option>
                        </select>
                      </label>
                    </div>
                  </div>
                ))}
              </section>
              <section className="panel form-panel points-panel">
                <div className="section-title">
                  <h2>Boarding & dropping points</h2>
                </div>
                <div className="point-grid">
                  <label className="field">
                    <span>Boarding point</span>
                    <select
                      value={boarding}
                      onChange={(event) => setBoarding(event.target.value)}
                    >
                      {activeTrip.boarding.map((point) => (
                        <option key={point}>{point}</option>
                      ))}
                    </select>
                  </label>
                  <label className="field">
                    <span>Dropping point</span>
                    <select
                      value={dropping}
                      onChange={(event) => setDropping(event.target.value)}
                    >
                      {activeTrip.dropping.map((point) => (
                        <option key={point}>{point}</option>
                      ))}
                    </select>
                  </label>
                </div>
              </section>
            </div>
            <BookingSummary
              trip={activeTrip}
              from={from}
              to={to}
              selected={selectedSeats}
              passengerCount={passengerCount}
              price={price}
              action="Review booking"
              onAction={() => navigate("review")}
              disabled={!passengersValid}
            />
          </div>
        </FlowPage>
      )}

      {page === "review" && (
        <FlowPage step={4} back={() => navigate("passengers")}>
          <div className="content-grid">
            <div className="review-stack">
              <section className="panel review-hero">
                <span className="eyebrow">Review your booking</span>
                <div className="route-line">
                  <div>
                    <strong>{activeTrip.departure}</strong>
                    <span>{from}</span>
                  </div>
                  <div className="route-track">
                    <BusFront size={20} />
                  </div>
                  <div className="align-right">
                    <strong>{activeTrip.arrival}</strong>
                    <span>{to}</span>
                  </div>
                </div>
                <div className="review-meta">
                  <span>
                    <CalendarDays size={17} /> {formatDate(date)}
                  </span>
                  <span>
                    <Clock3 size={17} /> {activeTrip.duration}
                  </span>
                  <span>
                    <BusFront size={17} /> {activeTrip.operator}
                  </span>
                </div>
              </section>
              <section className="panel review-section">
                <div className="review-section-head">
                  <h3>Passengers</h3>
                  <button onClick={() => navigate("passengers")}>Edit</button>
                </div>
                {passengers.map((passenger) => (
                  <div className="passenger-row" key={passenger.seat}>
                    <div className="avatar">
                      <UserRound size={16} />
                    </div>
                    <div>
                      <strong>{passenger.name}</strong>
                      <span>
                        {passenger.age} years · {passenger.gender}
                      </span>
                    </div>
                    <b>Seat {passenger.seat}</b>
                  </div>
                ))}
              </section>
              <section className="panel review-section">
                <div className="review-section-head">
                  <h3>Pickup & drop</h3>
                  <button onClick={() => navigate("passengers")}>Edit</button>
                </div>
                <div className="pickup-grid">
                  <div>
                    <MapPin size={19} />
                    <span>Boarding</span>
                    <strong>{boarding}</strong>
                  </div>
                  <div>
                    <Navigation size={19} />
                    <span>Dropping</span>
                    <strong>{dropping}</strong>
                  </div>
                </div>
              </section>
            </div>
            <aside className="summary-card review-summary">
              <h3>Fare summary</h3>
              <PriceRows price={price} />
              <div className="coupon">
                <label>
                  <span>Have a coupon?</span>
                  <div>
                    <input
                      value={coupon}
                      onChange={(e) => setCoupon(e.target.value)}
                      placeholder="WELCOME100"
                    />
                    <button
                      onClick={() =>
                        setCouponApplied(coupon.toUpperCase() === "WELCOME100")
                      }
                    >
                      Apply
                    </button>
                  </div>
                </label>
                {couponApplied && (
                  <p>
                    <Check size={14} /> Coupon applied successfully
                  </p>
                )}
              </div>
              <label className="check-row">
                <input
                  type="checkbox"
                  checked={terms}
                  onChange={(e) => setTerms(e.target.checked)}
                />
                <span>
                  I agree to the Terms & Conditions and cancellation policy.
                </span>
              </label>
              <Button disabled={!terms} onClick={() => navigate("payment")}>
                Confirm & proceed <ArrowRight size={18} />
              </Button>
            </aside>
          </div>
        </FlowPage>
      )}

      {page === "payment" && (
        <FlowPage step={5} back={() => navigate("review")}>
          <div className="payment-grid">
            <section className="panel payment-panel">
              <div className="secure-bar">
                <ShieldCheck size={20} />
                <span>
                  <strong>Secure payment</strong>Your payment information is
                  encrypted end-to-end.
                </span>
              </div>
              <div className="section-title">
                <span className="eyebrow">Payment</span>
                <h2>Choose how to pay</h2>
              </div>
              <div className="payment-methods">
                {[
                  ["upi", Smartphone, "UPI", "Google Pay, PhonePe, BHIM"],
                  [
                    "card",
                    CreditCard,
                    "Credit / Debit card",
                    "Visa, Mastercard, RuPay",
                  ],
                  [
                    "bank",
                    WalletCards,
                    "Net banking",
                    "All major Indian banks",
                  ],
                ].map(([id, Icon, label, note]) => (
                  <button
                    className={
                      paymentMethod === id
                        ? "payment-method active"
                        : "payment-method"
                    }
                    onClick={() => setPaymentMethod(id as string)}
                    key={id as string}
                  >
                    <span className="method-icon">
                      <Icon size={21} />
                    </span>
                    <span>
                      <strong>{label as string}</strong>
                      <small>{note as string}</small>
                    </span>
                    <span className="radio">
                      <i />
                    </span>
                  </button>
                ))}
              </div>
              {paymentMethod === "upi" && (
                <div className="payment-form">
                  <label className="field">
                    <span>UPI ID</span>
                    <input
                      placeholder="name@bank"
                      defaultValue="arjun@okaxis"
                    />
                  </label>
                  <p>
                    <Info size={15} /> A payment request will be sent to your
                    UPI app.
                  </p>
                </div>
              )}
              {paymentMethod === "card" && (
                <div className="payment-form card-form">
                  <label className="field wide">
                    <span>Card number</span>
                    <input placeholder="0000 0000 0000 0000" />
                  </label>
                  <label className="field">
                    <span>Expiry</span>
                    <input placeholder="MM / YY" />
                  </label>
                  <label className="field">
                    <span>CVV</span>
                    <input placeholder="•••" />
                  </label>
                </div>
              )}
            </section>
            <aside className="summary-card pay-summary">
              <div className="pay-trip">
                <span>{activeTrip.operator}</span>
                <strong>
                  {from} → {to}
                </strong>
                <small>
                  {formatDate(date)} · {selectedSeats.join(", ")}
                </small>
              </div>
              <PriceRows price={price} />
              <Button
                className="pay-button"
                onClick={completePayment}
                disabled={paying}
              >
                {paying ? (
                  <>
                    <span className="spinner" /> Processing securely…
                  </>
                ) : (
                  <>
                    Pay {formatMoney(price.total)} <LockKeyhole size={17} />
                  </>
                )}
              </Button>
              <p className="secure-note">
                <ShieldCheck size={16} /> PCI DSS secured checkout. No card data
                is stored.
              </p>
            </aside>
          </div>
        </FlowPage>
      )}

      {page === "success" && booking && (
        <Success booking={booking} navigate={navigate} />
      )}

      {page === "bookings" && (
        <Bookings
          bookings={savedBookings}
          user={user}
          openAuth={() => setAuthOpen(true)}
          navigate={navigate}
        />
      )}

      {authOpen && (
        <AuthModal
          mode={authMode}
          setMode={setAuthMode}
          close={() => setAuthOpen(false)}
          signIn={signIn}
        />
      )}
    </div>
  )
}

function Header({
  page,
  user,
  mobileNav,
  setMobileNav,
  navigate,
  openAuth,
}: {
  page: Page
  user: string | null
  mobileNav: boolean
  setMobileNav: (value: boolean) => void
  navigate: (page: Page) => void
  openAuth: (mode: "login" | "signup") => void
}) {
  return (
    <header className="header">
      <div className="nav-wrap">
        <button
          className="brand"
          onClick={() => navigate("home")}
          aria-label="Wayfare home"
        >
          <span className="brand-mark">
            <BusFront size={22} />
          </span>
          <span>wayfare</span>
        </button>
        <nav className={mobileNav ? "nav-links open" : "nav-links"}>
          <button
            className={page === "home" ? "active" : ""}
            onClick={() => navigate("home")}
          >
            Home
          </button>
          <button
            className={page === "results" ? "active" : ""}
            onClick={() => navigate("results")}
          >
            Bus tickets
          </button>
          <button
            className={page === "bookings" ? "active" : ""}
            onClick={() => navigate("bookings")}
          >
            My bookings
          </button>
          <button>Help</button>
        </nav>
        <div className="nav-actions">
          <button className="help-button">
            <CircleHelp size={18} />
            <span>Support</span>
          </button>
          {user ? (
            <button
              className="profile-button"
              onClick={() => navigate("bookings")}
            >
              <span>{user.charAt(0)}</span>
              <b>{user.split(" ")[0]}</b>
              <ChevronDown size={15} />
            </button>
          ) : (
            <>
              <button
                className="login-button"
                onClick={() => openAuth("login")}
              >
                Log in
              </button>
              <Button
                className="signup-button"
                onClick={() => openAuth("signup")}
              >
                Sign up
              </Button>
            </>
          )}
          <button
            className="menu-button"
            onClick={() => setMobileNav(!mobileNav)}
            aria-label="Menu"
          >
            {mobileNav ? <X /> : <Menu />}
          </button>
        </div>
      </div>
    </header>
  )
}

function Home({
  from,
  to,
  date,
  passengerCount,
  setFrom,
  setTo,
  setDate,
  setPassengerCount,
  search,
}: {
  from: string
  to: string
  date: string
  passengerCount: number
  setFrom: (value: string) => void
  setTo: (value: string) => void
  setDate: (value: string) => void
  setPassengerCount: (value: number) => void
  search: () => void
}) {
  return (
    <main>
      <section className="hero">
        <div className="hero-orb orb-one" />
        <div className="hero-orb orb-two" />
        <div className="hero-copy">
          <div className="trust-pill">
            <span>
              <Check size={13} />
            </span>{" "}
            Trusted by 2 million+ travellers
          </div>
          <h1>
            Go farther.
            <br />
            <em>Travel better.</em>
          </h1>
          <p>
            Book reliable intercity buses at the best prices. Simple search,
            live seats, and secure checkout.
          </p>
        </div>
        <div className="hero-image">
          <img
            src="https://images.unsplash.com/photo-1680688099493-03b7c933206a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=85&w=1400"
            alt="Blue intercity bus travelling through a city"
          />
          <div className="image-stat">
            <strong>4.8</strong>
            <span>
              <Star size={14} fill="currentColor" /> average trip rating
            </span>
          </div>
        </div>
        <div className="search-card">
          <div className="search-head">
            <div>
              <span className="eyebrow">Plan your journey</span>
              <h2>Where are you headed?</h2>
            </div>
            <div className="trip-type">
              <span className="active">One way</span>
              <span>Round trip</span>
            </div>
          </div>
          <div className="search-grid">
            <label className="search-field">
              <span>From</span>
              <div>
                <MapPin size={19} />
                <input value={from} onChange={(e) => setFrom(e.target.value)} />
              </div>
              <small>Chennai, Tamil Nadu</small>
            </label>
            <button
              className="swap-button"
              onClick={() => {
                setFrom(to)
                setTo(from)
              }}
              aria-label="Swap cities"
            >
              <ArrowUpDown size={18} />
            </button>
            <label className="search-field">
              <span>To</span>
              <div>
                <Navigation size={19} />
                <input value={to} onChange={(e) => setTo(e.target.value)} />
              </div>
              <small>Bengaluru, Karnataka</small>
            </label>
            <label className="search-field">
              <span>Journey date</span>
              <div>
                <CalendarDays size={19} />
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                />
              </div>
              <small>{date && formatDate(date)}</small>
            </label>
            <label className="search-field">
              <span>Passengers</span>
              <div className="passenger-stepper">
                <UsersRound size={19} />
                <strong>{passengerCount}</strong>
                <span>{passengerCount === 1 ? "Traveller" : "Travellers"}</span>
                <button
                  onClick={() =>
                    setPassengerCount(Math.max(1, passengerCount - 1))
                  }
                >
                  <Minus size={14} />
                </button>
                <button
                  onClick={() =>
                    setPassengerCount(Math.min(6, passengerCount + 1))
                  }
                >
                  <Plus size={14} />
                </button>
              </div>
              <small>Adults</small>
            </label>
            <Button className="search-button" onClick={search}>
              <Search size={20} /> Search buses
            </Button>
          </div>
        </div>
      </section>

      <section className="confidence">
        <div>
          <span>
            <ShieldCheck />
          </span>
          <div>
            <strong>Safe & secure</strong>
            <small>Protected payments</small>
          </div>
        </div>
        <div>
          <span>
            <Zap />
          </span>
          <div>
            <strong>Instant confirmation</strong>
            <small>Tickets in seconds</small>
          </div>
        </div>
        <div>
          <span>
            <Ticket />
          </span>
          <div>
            <strong>Best fares</strong>
            <small>No hidden charges</small>
          </div>
        </div>
        <div>
          <span>
            <CircleHelp />
          </span>
          <div>
            <strong>24/7 support</strong>
            <small>Always here to help</small>
          </div>
        </div>
      </section>

      <section className="popular">
        <div className="section-heading">
          <div>
            <span className="eyebrow">Popular routes</span>
            <h2>Journeys people love</h2>
          </div>
          <button>
            Explore all routes <ArrowRight size={17} />
          </button>
        </div>
        <div className="route-cards">
          {[
            ["Chennai", "Bangalore", "from ₹649", "7h 45m"],
            ["Bangalore", "Hyderabad", "from ₹799", "9h 10m"],
            ["Chennai", "Coimbatore", "from ₹599", "8h 00m"],
          ].map((route, index) => (
            <button className="route-card" key={route[1]}>
              <span className={`route-number route-${index + 1}`}>
                0{index + 1}
              </span>
              <div>
                <strong>{route[0]}</strong>
                <span>
                  <ArrowRight size={16} />
                </span>
                <strong>{route[1]}</strong>
              </div>
              <small>{route[3]}</small>
              <b>{route[2]}</b>
            </button>
          ))}
        </div>
      </section>
    </main>
  )
}

function Results({
  from,
  to,
  date,
  passengerCount,
  sort,
  setSort,
  filtersOpen,
  setFiltersOpen,
  chooseTrip,
  back,
}: {
  from: string
  to: string
  date: string
  passengerCount: number
  sort: string
  setSort: (sort: string) => void
  filtersOpen: boolean
  setFiltersOpen: (open: boolean) => void
  chooseTrip: (trip: BusTrip) => void
  back: () => void
}) {
  const displayedTrips = [...trips].sort((a, b) => {
    if (sort === "Lowest price") return a.fare - b.fare
    if (sort === "Highest rated") return b.rating - a.rating
    if (sort === "Earliest") return a.departure.localeCompare(b.departure)
    return b.rating - a.rating
  })
  return (
    <main className="results-page">
      <div className="results-search-bar">
        <div className="route-summary">
          <button onClick={back}>
            <ArrowLeft size={19} />
          </button>
          <div>
            <strong>{from}</strong>
            <ArrowRight size={18} />
            <strong>{to}</strong>
          </div>
          <span>
            {formatDate(date)} · {passengerCount} travellers
          </span>
        </div>
        <Button variant="secondary" onClick={back}>
          Modify search
        </Button>
      </div>
      <div className="results-wrap">
        <aside className={filtersOpen ? "filters open" : "filters"}>
          <div className="filter-head">
            <strong>Filters</strong>
            <button onClick={() => setFiltersOpen(false)}>
              <X size={19} />
            </button>
            <span>Reset all</span>
          </div>
          <FilterGroup title="Bus type">
            {["AC Sleeper", "Seater", "Ultra Deluxe"].map((item, index) => (
              <CheckOption key={item} text={item} count={[8, 5, 3][index]} />
            ))}
          </FilterGroup>
          <FilterGroup title="Departure time">
            {["Before 10 AM", "10 AM – 5 PM", "After 5 PM"].map((item) => (
              <CheckOption key={item} text={item} />
            ))}
          </FilterGroup>
          <FilterGroup title="Price range">
            <div className="range-values">
              <span>₹500</span>
              <span>₹1,500</span>
            </div>
            <input className="range" type="range" min="500" max="1500" />
          </FilterGroup>
          <FilterGroup title="Amenities">
            {["WiFi", "Charging point", "Blanket", "Live tracking"].map(
              (item) => (
                <CheckOption key={item} text={item} />
              ),
            )}
          </FilterGroup>
        </aside>
        <section className="results-content">
          <div className="results-title">
            <div>
              <h1>{displayedTrips.length} buses found</h1>
              <p>
                {from} to {to} · {formatDate(date)}
              </p>
            </div>
            <div className="result-controls">
              <Button
                variant="secondary"
                className="mobile-filter"
                onClick={() => setFiltersOpen(true)}
              >
                <Filter size={17} /> Filters
              </Button>
              <label>
                Sort by{" "}
                <select value={sort} onChange={(e) => setSort(e.target.value)}>
                  <option>Recommended</option>
                  <option>Lowest price</option>
                  <option>Highest rated</option>
                  <option>Earliest</option>
                </select>
              </label>
            </div>
          </div>
          <div className="result-list">
            {displayedTrips.map((trip, index) => (
              <TripCard
                key={trip.id}
                trip={trip}
                tag={
                  index === 0
                    ? "Top rated"
                    : index === 1
                      ? "Popular choice"
                      : ""
                }
                choose={() => chooseTrip(trip)}
              />
            ))}
          </div>
        </section>
      </div>
    </main>
  )
}

function FilterGroup({
  title,
  children,
}: {
  title: string
  children: React.ReactNode
}) {
  return (
    <div className="filter-group">
      <h3>
        {title}
        <ChevronDown size={16} />
      </h3>
      {children}
    </div>
  )
}

function CheckOption({ text, count }: { text: string count?: number }) {
  return (
    <label className="filter-option">
      <input type="checkbox" />
      <span>{text}</span>
      {count && <small>{count}</small>}
    </label>
  )
}

function TripCard({
  trip,
  tag,
  choose,
}: {
  trip: BusTrip
  tag: string
  choose: () => void
}) {
  return (
    <article className="trip-card">
      {tag && <span className="trip-tag">{tag}</span>}
      <div className="trip-main">
        <div className="operator">
          <div className="operator-logo">
            {trip.operator
              .split(" ")
              .map((word) => word[0])
              .join("")
              .slice(0, 2)}
          </div>
          <div>
            <h2>{trip.operator}</h2>
            <p>{trip.coach}</p>
          </div>
        </div>
        <div className="trip-timeline">
          <div>
            <strong>{trip.departure}</strong>
            <span>Chennai</span>
            <small>Koyambedu</small>
          </div>
          <div className="duration">
            <span>{trip.duration}</span>
            <i>
              <BusFront size={15} />
            </i>
            <small>Overnight</small>
          </div>
          <div className="align-right">
            <strong>{trip.arrival}</strong>
            <span>Bangalore</span>
            <small>Majestic</small>
          </div>
        </div>
        <div className="trip-price">
          <div className="rating">
            <Star size={14} fill="currentColor" /> {trip.rating}
            <span>({trip.reviews})</span>
          </div>
          <small>Starting from</small>
          <strong>{formatMoney(trip.fare)}</strong>
          <span>per seat</span>
        </div>
      </div>
      <div className="trip-foot">
        <div className="amenities">
          {trip.amenities.map((amenity) => (
            <span key={amenity}>
              {amenity === "WiFi" ? (
                <Wifi size={15} />
              ) : amenity === "Charging" ? (
                <Zap size={15} />
              ) : (
                <Check size={14} />
              )}
              {amenity}
            </span>
          ))}
        </div>
        <div className="seats-left">
          <span className={trip.available < 10 ? "low" : ""}>
            {trip.available} seats left
          </span>
          <Button onClick={choose}>
            View seats <ChevronRight size={17} />
          </Button>
        </div>
      </div>
    </article>
  )
}

function FlowPage({
  step,
  back,
  children,
}: {
  step: number
  back: () => void
  children: React.ReactNode
}) {
  const labels = [
    "Search",
    "Seats",
    "Passenger details",
    "Review",
    "Payment",
    "Confirmation",
  ]
  return (
    <main className="flow-page">
      <div className="flow-top">
        <button className="back-link" onClick={back}>
          <ArrowLeft size={18} /> Back
        </button>
        <div className="progress">
          {labels.map((label, index) => (
            <div
              className={
                index + 1 < step ? "done" : index + 1 === step ? "active" : ""
              }
              key={label}
            >
              <span>{index + 1 < step ? <Check size={13} /> : index + 1}</span>
              <small>{label}</small>
            </div>
          ))}
        </div>
      </div>
      <div className="flow-content">{children}</div>
    </main>
  )
}

function SeatLegend() {
  return (
    <div className="seat-legend">
      <span>
        <i className="available" /> Available
      </span>
      <span>
        <i className="selected" /> Selected
      </span>
      <span>
        <i className="booked" /> Booked
      </span>
      <span>
        <i className="female" /> Female only
      </span>
    </div>
  )
}

function SeatMap({
  type,
  deck,
  selected,
  toggle,
}: {
  type: BusType
  deck: "upper" | "lower"
  selected: string[]
  toggle: (seat: string, state: SeatState) => void
}) {
  const stateFor = (index: number): SeatState => {
    if ([3, 10, 19, 27, 38].includes(index)) return "booked"
    if ([7, 22].includes(index)) return "female"
    if ([14].includes(index)) return "locked"
    return "available"
  }

  if (type === "Seater" || (type === "Ultra Deluxe" && deck === "lower")) {
    const count = type === "Seater" ? 52 : 24
    const prefix = type === "Ultra Deluxe" ? "L" : "S"
    return (
      <div className="bus-shell">
        <div className="driver">
          <span />
          <small>Driver</small>
        </div>
        <div className="seater-grid">
          {Array.from({ length: count }).map((_, index) => {
            const label = `${prefix}${index + 1}`
            const state = stateFor(index)
            return (
              <button
                key={label}
                className={`seat ${
                  selected.includes(label) ? "selected" : state
                } ${index % 4 === 1 ? "aisle-after" : ""}`}
                onClick={() => toggle(label, state)}
                title={`${label} · ${state}`}
              >
                <i />
                <span>{label}</span>
              </button>
            )
          })}
        </div>
        <div className="bus-front-label">Front of bus</div>
      </div>
    )
  }

  const prefix = deck === "upper" ? "U" : "L"
  return (
    <div className="bus-shell sleeper-shell">
      <div className="sleeper-label">
        <span>{deck} deck</span>
        <small>15 sleeper berths</small>
      </div>
      <div className="sleeper-grid">
        {Array.from({ length: 15 }).map((_, index) => {
          const label = `${prefix}${index + 1}`
          const state = stateFor(index + (deck === "upper" ? 2 : 0))
          return (
            <button
              key={label}
              className={`berth ${
                selected.includes(label) ? "selected" : state
              }`}
              onClick={() => toggle(label, state)}
            >
              <i />
              <span>{label}</span>
              <small>{deck === "upper" ? "Upper" : "Lower"}</small>
            </button>
          )
        })}
      </div>
      <div className="bus-front-label">Front of bus</div>
    </div>
  )
}

function BookingSummary({
  trip,
  from,
  to,
  selected,
  passengerCount,
  price,
  action,
  onAction,
  disabled,
}: {
  trip: BusTrip
  from: string
  to: string
  selected: string[]
  passengerCount: number
  price: {
    base: number
    seatPremium: number
    taxes: number
    fee: number
    discount: number
    total: number
  }
  action: string
  onAction: () => void
  disabled: boolean
}) {
  return (
    <aside className="summary-card">
      <div className="summary-route">
        <span>Trip summary</span>
        <strong>
          {from} <ArrowRight size={15} /> {to}
        </strong>
        <small>
          {trip.departure} · {trip.operator}
        </small>
      </div>
      <div className="selected-summary">
        <div>
          <span>Selected seats</span>
          <small>
            {selected.length} of {passengerCount}
          </small>
        </div>
        <div className="seat-chips">
          {selected.length ? (
            selected.map((seat) => <b key={seat}>{seat}</b>)
          ) : (
            <p>Select {passengerCount} seats from the map</p>
          )}
        </div>
      </div>
      <PriceRows price={price} />
      <Button disabled={disabled} onClick={onAction}>
        {action} <ArrowRight size={18} />
      </Button>
      {disabled && selected.length > 0 && (
        <p className="summary-hint">
          Select {passengerCount - selected.length} more seat
          {passengerCount - selected.length !== 1 ? "s" : ""} to continue
        </p>
      )}
      <div className="support-note">
        <ShieldCheck size={17} />
        <span>
          <strong>Free cancellation</strong>until 6 hours before departure
        </span>
      </div>
    </aside>
  )
}

function PriceRows({
  price,
}: {
  price: {
    base: number
    seatPremium: number
    taxes: number
    fee: number
    discount: number
    total: number
  }
}) {
  return (
    <div className="price-rows">
      <div>
        <span>Base fare</span>
        <strong>{formatMoney(price.base)}</strong>
      </div>
      {price.seatPremium > 0 && (
        <div>
          <span>Upper berth premium</span>
          <strong>{formatMoney(price.seatPremium)}</strong>
        </div>
      )}
      <div>
        <span>Taxes</span>
        <strong>{formatMoney(price.taxes)}</strong>
      </div>
      <div>
        <span>Convenience fee</span>
        <strong>{formatMoney(price.fee)}</strong>
      </div>
      {price.discount > 0 && (
        <div className="discount">
          <span>Coupon discount</span>
          <strong>−{formatMoney(price.discount)}</strong>
        </div>
      )}
      <div className="total">
        <span>Total</span>
        <strong>{formatMoney(price.total)}</strong>
      </div>
    </div>
  )
}

function AuthModal({
  mode,
  setMode,
  close,
  signIn,
}: {
  mode: "login" | "signup"
  setMode: (mode: "login" | "signup") => void
  close: () => void
  signIn: (name?: string) => void
}) {
  const [name, setName] = useState("")
  const [email, setEmail] = useState("arjun@example.com")
  const [password, setPassword] = useState("password")
  return (
    <div className="modal-backdrop" role="dialog" aria-modal="true">
      <div className="auth-modal">
        <button className="modal-close" onClick={close}>
          <X size={20} />
        </button>
        <div className="auth-brand">
          <span>
            <BusFront size={21} />
          </span>
          wayfare
        </div>
        <span className="eyebrow">
          {mode === "login" ? "Welcome back" : "Join wayfare"}
        </span>
        <h2>
          {mode === "login" ? "Log in to continue" : "Create your account"}
        </h2>
        <p>
          {mode === "login"
            ? "Your selected seats will stay held while you sign in."
            : "Book faster and keep every journey in one place."}
        </p>
        <div className="auth-form">
          {mode === "signup" && (
            <label className="field">
              <span>Full name</span>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Your full name"
              />
            </label>
          )}
          <label className="field">
            <span>Email or mobile</span>
            <input value={email} onChange={(e) => setEmail(e.target.value)} />
          </label>
          {mode === "signup" && (
            <label className="field">
              <span>Mobile number</span>
              <input placeholder="+91 98765 43210" />
            </label>
          )}
          <label className="field">
            <span>Password</span>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </label>
          <div className="auth-options">
            <label>
              <input type="checkbox" defaultChecked /> Remember me
            </label>
            <button>Forgot password?</button>
          </div>
          <Button onClick={() => signIn(name || "Arjun Mehta")}>
            {mode === "login" ? "Log in" : "Create account"}{" "}
            <ArrowRight size={17} />
          </Button>
          <div className="auth-divider">
            <span>or continue with</span>
          </div>
          <Button variant="secondary" onClick={() => signIn("Arjun Mehta")}>
            <b className="google-g">G</b> Google
          </Button>
        </div>
        <p className="auth-switch">
          {mode === "login" ? "New to wayfare?" : "Already have an account?"}{" "}
          <button
            onClick={() => setMode(mode === "login" ? "signup" : "login")}
          >
            {mode === "login" ? "Create an account" : "Log in"}
          </button>
        </p>
      </div>
    </div>
  )
}

function Success({
  booking,
  navigate,
}: {
  booking: Booking
  navigate: (page: Page) => void
}) {
  return (
    <main className="success-page">
      <div className="success-glow" />
      <div className="success-card">
        <div className="success-icon">
          <Check size={30} />
        </div>
        <span className="eyebrow">Payment successful</span>
        <h1>Your journey is confirmed.</h1>
        <p>Your ticket has been sent to your registered email and mobile.</p>
        <div className="ticket-card">
          <div className="ticket-top">
            <div>
              <span>Booking ID</span>
              <strong>{booking.id}</strong>
            </div>
            <div>
              <span>PNR</span>
              <strong>{booking.pnr}</strong>
            </div>
            <b>Confirmed</b>
          </div>
          <div className="ticket-route">
            <div>
              <strong>{booking.departure}</strong>
              <span>{booking.from}</span>
            </div>
            <div>
              <small>{formatDate(booking.date)}</small>
              <i>
                <BusFront size={18} />
              </i>
              <span>{activeDuration(booking.departure, booking.arrival)}</span>
            </div>
            <div className="align-right">
              <strong>{booking.arrival}</strong>
              <span>{booking.to}</span>
            </div>
          </div>
          <div className="ticket-details">
            <div>
              <span>Operator</span>
              <strong>{booking.operator}</strong>
            </div>
            <div>
              <span>Seats</span>
              <strong>{booking.seats.join(", ")}</strong>
            </div>
            <div>
              <span>Passengers</span>
              <strong>{booking.passengers.length}</strong>
            </div>
            <div>
              <span>Amount paid</span>
              <strong>{formatMoney(booking.amount)}</strong>
            </div>
          </div>
          <div className="ticket-code">
            <span />
            <span />
            <span />
            <span />
            <span />
            <span />
            <span />
            <span />
            <small>{booking.pnr}</small>
          </div>
        </div>
        <div className="success-actions">
          <Button onClick={() => navigate("bookings")}>View booking</Button>
          <Button variant="secondary" onClick={() => window.print()}>
            <Download size={17} /> Download ticket
          </Button>
          <button onClick={() => navigate("home")}>Go to home</button>
        </div>
      </div>
    </main>
  )
}

function activeDuration(departure: string, arrival: string) {
  const [dH, dM] = departure.split(":").map(Number)
  const [aH, aM] = arrival.split(":").map(Number)
  let minutes = aH * 60 + aM - (dH * 60 + dM)
  if (minutes < 0) minutes += 24 * 60
  return `${Math.floor(minutes / 60)}h ${String(minutes % 60).padStart(2, "0")}m`
}

function Bookings({
  bookings,
  user,
  openAuth,
  navigate,
}: {
  bookings: Booking[]
  user: string | null
  openAuth: () => void
  navigate: (page: Page) => void
}) {
  if (!user) {
    return (
      <main className="empty-bookings">
        <div>
          <span>
            <Ticket size={30} />
          </span>
          <h1>Keep every journey in one place</h1>
          <p>
            Log in to view tickets, download boarding passes, and manage
            cancellations.
          </p>
          <Button onClick={openAuth}>Log in to continue</Button>
        </div>
      </main>
    )
  }
  return (
    <main className="bookings-page">
      <div className="bookings-header">
        <span className="eyebrow">Your journeys</span>
        <h1>My bookings</h1>
        <p>Welcome back, {user}. Manage your upcoming and past travel.</p>
      </div>
      <div className="booking-tabs">
        <button className="active">
          Upcoming <span>{bookings.length}</span>
        </button>
        <button>Completed</button>
        <button>Cancelled</button>
      </div>
      {bookings.length === 0 ? (
        <div className="no-bookings">
          <span>
            <Ticket size={28} />
          </span>
          <h2>No upcoming journeys</h2>
          <p>When you book a bus, your ticket will appear here.</p>
          <Button onClick={() => navigate("home")}>Find a bus</Button>
        </div>
      ) : (
        <div className="booking-list">
          {bookings.map((item) => (
            <article className="booking-item" key={item.id}>
              <div className="booking-status">
                <span>Upcoming</span>
                <b>{item.status}</b>
              </div>
              <div className="booking-route">
                <div>
                  <strong>{item.departure}</strong>
                  <span>{item.from}</span>
                </div>
                <div>
                  <small>{formatDate(item.date)}</small>
                  <i>
                    <BusFront size={17} />
                  </i>
                </div>
                <div className="align-right">
                  <strong>{item.arrival}</strong>
                  <span>{item.to}</span>
                </div>
              </div>
              <div className="booking-info">
                <div>
                  <span>Bus</span>
                  <strong>{item.operator}</strong>
                  <small>{item.type}</small>
                </div>
                <div>
                  <span>Booking ID / PNR</span>
                  <strong>{item.id}</strong>
                  <small>{item.pnr}</small>
                </div>
                <div>
                  <span>Seats</span>
                  <strong>{item.seats.join(", ")}</strong>
                  <small>{item.passengers.length} passengers</small>
                </div>
                <div>
                  <span>Amount</span>
                  <strong>{formatMoney(item.amount)}</strong>
                  <small>Paid</small>
                </div>
              </div>
              <div className="booking-actions">
                <Button variant="secondary">View details</Button>
                <Button variant="ghost" onClick={() => window.print()}>
                  <Download size={16} /> Download ticket
                </Button>
                <button className="cancel-link">Cancel booking</button>
              </div>
            </article>
          ))}
        </div>
      )}
    </main>
  )
}

export default App
